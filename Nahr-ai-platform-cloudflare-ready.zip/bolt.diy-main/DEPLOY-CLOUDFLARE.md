# Nahr AI Platform — Cloudflare deployment notes

This repository is based on Bolt.diy. The Cloudflare Workers entry point is configured in `wrangler.jsonc`.

## Cloudflare Workers setup

- Repository: `Fahim1230a/Nahr-ai-platform`
- Build command: `pnpm run build`
- Deploy command: `npx wrangler deploy`
- Preview command (optional): `npx wrangler dev`
- Project name in `wrangler.jsonc`: `nahr-ai-platform`

Use the Node.js version required by the repository's `package.json` and its lockfile. Keep `pnpm-lock.yaml` committed and do not mix npm/yarn lockfiles.

## Required configuration

1. Review `.env.example` and identify only the providers you intend to use.
2. Add required API keys as Cloudflare Worker secrets or environment variables in the Cloudflare dashboard. Never commit `.env`, `.env.local`, API keys, or private tokens.
3. Deploy only after the repository contains the source files and lockfile and the build succeeds.
4. This deployment hosts the web application. It does not automatically build a native Windows app or implement the planned Nahr language, Arabic UI, live avatar, or game-generation integrations; those are separate development tasks.

## Important

Bolt.diy relies on browser capabilities including WebContainers. Test the deployed app on the target mobile browser and verify provider configuration before treating it as production-ready.
