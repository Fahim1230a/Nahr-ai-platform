import type { UIMessage } from 'ai';
import { migrateLegacyMessages } from './messageMigration';
import type { Snapshot } from './types'; // Import Snapshot type
import type { ChatHistoryItem } from './useChatHistory';
import { createScopedLogger } from '~/utils/logger';

export interface IChatMetadata {
  gitUrl: string;
  gitBranch?: string;
  netlifySiteId?: string;
}

const logger = createScopedLogger('ChatHistory');

// this is used at the top level and never rejects
export async function openDatabase(): Promise<IDBDatabase | undefined> {
  if (typeof indexedDB === 'undefined') {
    console.error('indexedDB is not available in this environment.');
    return undefined;
  }

  return new Promise((resolve) => {
    const request = indexedDB.open('boltHistory', 2);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const oldVersion = event.oldVersion;

      if (oldVersion < 1) {
        if (!db.objectStoreNames.contains('chats')) {
          const store = db.createObjectStore('chats', { keyPath: 'id' });
          store.createIndex('id', 'id', { unique: true });
          store.createIndex('urlId', 'urlId', { unique: true });
        }
      }

      if (oldVersion < 2) {
        if (!db.objectStoreNames.contains('snapshots')) {
          db.createObjectStore('snapshots', { keyPath: 'chatId' });
        }
      }
    };

    request.onsuccess = (event: Event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };

    request.onerror = (event: Event) => {
      resolve(undefined);
      logger.error((event.target as IDBOpenDBRequest).error);
    };
  });
}

export async function getAll(db: IDBDatabase): Promise<ChatHistoryItem[]> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('chats', 'readonly');
    const store = transaction.objectStore('chats');
    const request = store.getAll();

    /*
     * Chats persisted by v4 have no `parts`. convertToModelMessages reads
     * message.parts directly, so anything handed to useChat must be migrated
     * first. migrateLegacyMessages is idempotent, so re-reading a chat that was
     * already migrated on disk is a no-op.
     */
    request.onsuccess = () =>
      resolve((request.result as ChatHistoryItem[]).map(migrateChatMessages) as ChatHistoryItem[]);
    request.onerror = () => reject(request.error);
  });
}

/*
 * Returns a migrated copy of a stored chat. The stored record is only ever
 * rewritten by an explicit write path, and the read-modify-write helpers plus
 * the export path use the *Raw readers so a pre-v7 chat keeps its original
 * shape on disk.
 */
export function migrateChatMessages(chat: ChatHistoryItem): ChatHistoryItem {
  if (!chat || !Array.isArray(chat.messages)) {
    return chat;
  }

  return { ...chat, messages: migrateLegacyMessages(chat.messages) } as ChatHistoryItem;
}

export async function setMessages(
  db: IDBDatabase,
  id: string,
  messages: UIMessage[],
  urlId?: string,
  description?: string,
  timestamp?: string,
  metadata?: IChatMetadata,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('chats', 'readwrite');
    const store = transaction.objectStore('chats');

    if (timestamp && isNaN(Date.parse(timestamp))) {
      reject(new Error('Invalid timestamp'));
      return;
    }

    const request = store.put({
      id,
      messages,
      urlId,
      description,
      timestamp: timestamp ?? new Date().toISOString(),
      metadata,
    });

    transaction.oncomplete = () => resolve();
    request.onerror = () => reject(request.error);
    transaction.onerror = () => reject(transaction.error || request.error);
    transaction.onabort = () => reject(transaction.error || new Error('Chat message save was aborted'));
  });
}

export async function getMessages(db: IDBDatabase, id: string): Promise<ChatHistoryItem> {
  return (await getMessagesById(db, id)) || (await getMessagesByUrlId(db, id));
}

export async function getMessagesByUrlId(db: IDBDatabase, id: string): Promise<ChatHistoryItem> {
  return migrateChatMessages(await getMessagesByUrlIdRaw(db, id));
}

/*
 * Un-migrated read. Required by the single-chat export path, which must stay
 * lossless, and by the read-modify-write helpers below, which would otherwise
 * rewrite a pre-v7 chat's messages into the v5 shape and drop `content`,
 * `annotations` and any unknown fields from the original record.
 */
export async function getMessagesByUrlIdRaw(db: IDBDatabase, id: string): Promise<ChatHistoryItem> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('chats', 'readonly');
    const store = transaction.objectStore('chats');
    const index = store.index('urlId');
    const request = index.get(id);

    request.onsuccess = () => resolve(request.result as ChatHistoryItem);
    request.onerror = () => reject(request.error);
  });
}

export async function getMessagesById(db: IDBDatabase, id: string): Promise<ChatHistoryItem> {
  return migrateChatMessages(await getMessagesByIdRaw(db, id));
}

export async function getMessagesByIdRaw(db: IDBDatabase, id: string): Promise<ChatHistoryItem> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('chats', 'readonly');
    const store = transaction.objectStore('chats');
    const request = store.get(id);

    request.onsuccess = () => resolve(request.result as ChatHistoryItem);
    request.onerror = () => reject(request.error);
  });
}

export async function deleteById(db: IDBDatabase, id: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['chats', 'snapshots'], 'readwrite'); // Add snapshots store to transaction
    const chatStore = transaction.objectStore('chats');
    const snapshotStore = transaction.objectStore('snapshots');

    const deleteChatRequest = chatStore.delete(id);
    const deleteSnapshotRequest = snapshotStore.delete(id); // Also delete snapshot

    let chatDeleted = false;
    let snapshotDeleted = false;

    const checkCompletion = () => {
      if (chatDeleted && snapshotDeleted) {
        resolve(undefined);
      }
    };

    deleteChatRequest.onsuccess = () => {
      chatDeleted = true;
      checkCompletion();
    };
    deleteChatRequest.onerror = () => reject(deleteChatRequest.error);

    deleteSnapshotRequest.onsuccess = () => {
      snapshotDeleted = true;
      checkCompletion();
    };

    deleteSnapshotRequest.onerror = (event) => {
      if ((event.target as IDBRequest).error?.name === 'NotFoundError') {
        snapshotDeleted = true;
        checkCompletion();
      } else {
        reject(deleteSnapshotRequest.error);
      }
    };

    transaction.oncomplete = () => {
      // This might resolve before checkCompletion if one operation finishes much faster
    };
    transaction.onerror = () => reject(transaction.error);
  });
}

/**
 * Allocate the next numeric chat ID and persist the chat in one readwrite
 * transaction. IndexedDB serializes overlapping readwrite transactions, so a
 * concurrent creator observes the ID written by the previous transaction.
 */
export async function createChatWithNextId(
  db: IDBDatabase,
  messages: UIMessage[],
  urlId?: string,
  description?: string,
  metadata?: IChatMetadata,
  ensureUrlId = false,
): Promise<{ id: string; urlId?: string }> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('chats', 'readwrite');
    const store = transaction.objectStore('chats');

    let created: { id: string; urlId?: string } | undefined;
    let highestId = 0;

    const usedUrlIds = new Set<string>();

    let scansRemaining = ensureUrlId ? 2 : 1;

    const finishScan = () => {
      scansRemaining--;

      if (scansRemaining > 0) {
        return;
      }

      const id = String(highestId + 1);
      const baseUrlId = urlId || id;

      let finalUrlId = urlId;

      if (ensureUrlId) {
        finalUrlId = baseUrlId;

        let suffix = 2;

        while (usedUrlIds.has(finalUrlId)) {
          finalUrlId = `${baseUrlId}-${suffix++}`;
        }
      }

      store.add({
        id,
        messages,
        urlId: finalUrlId,
        description,
        timestamp: new Date().toISOString(),
        metadata,
      });
      created = { id, urlId: finalUrlId };
    };

    const idCursorRequest = store.openKeyCursor();

    idCursorRequest.onsuccess = () => {
      const cursor = idCursorRequest.result;

      if (cursor) {
        highestId = Math.max(highestId, Number(cursor.key) || 0);
        cursor.continue();
      } else {
        finishScan();
      }
    };
    idCursorRequest.onerror = () => reject(idCursorRequest.error);

    if (ensureUrlId) {
      const urlIdIndex = store.index('urlId');
      const urlIdCursorRequest = urlIdIndex.openKeyCursor();

      urlIdCursorRequest.onsuccess = () => {
        const cursor = urlIdCursorRequest.result;

        if (cursor) {
          if (typeof cursor.key === 'string') {
            usedUrlIds.add(cursor.key);
          }

          cursor.continue();
        } else {
          finishScan();
        }
      };
      urlIdCursorRequest.onerror = () => reject(urlIdCursorRequest.error);
    }

    transaction.oncomplete = () => {
      if (created) {
        resolve(created);
      } else {
        reject(new Error('Chat creation transaction completed without creating a chat'));
      }
    };
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error || new Error('Chat creation was aborted'));
  });
}

export async function getUrlId(db: IDBDatabase, id: string): Promise<string> {
  const idList = await getUrlIds(db);

  if (!idList.includes(id)) {
    return id;
  } else {
    let i = 2;

    while (idList.includes(`${id}-${i}`)) {
      i++;
    }

    return `${id}-${i}`;
  }
}

async function getUrlIds(db: IDBDatabase): Promise<string[]> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('chats', 'readonly');
    const store = transaction.objectStore('chats');
    const idList: string[] = [];

    const request = store.openCursor();

    request.onsuccess = (event: Event) => {
      const cursor = (event.target as IDBRequest<IDBCursorWithValue>).result;

      if (cursor) {
        idList.push(cursor.value.urlId);
        cursor.continue();
      } else {
        resolve(idList);
      }
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

export async function forkChat(db: IDBDatabase, chatId: string, messageId: string): Promise<string> {
  const chat = await getMessagesByIdRaw(db, chatId);

  if (!chat) {
    throw new Error('Chat not found');
  }

  // Find the index of the message to fork at
  const messageIndex = chat.messages.findIndex((msg) => msg.id === messageId);

  if (messageIndex === -1) {
    throw new Error('Message not found');
  }

  // Get messages up to and including the selected message
  const messages = chat.messages.slice(0, messageIndex + 1);

  return createChatFromMessages(db, chat.description ? `${chat.description} (fork)` : 'Forked chat', messages);
}

export async function duplicateChat(db: IDBDatabase, id: string): Promise<string> {
  const chat = await getMessagesByIdRaw(db, id);

  if (!chat) {
    throw new Error('Chat not found');
  }

  return createChatFromMessages(db, `${chat.description || 'Chat'} (copy)`, chat.messages);
}

export async function createChatFromMessages(
  db: IDBDatabase,
  description: string,
  messages: UIMessage[],
  metadata?: IChatMetadata,
): Promise<string> {
  const created = await createChatWithNextId(db, messages, undefined, description, metadata, true);

  return created.urlId!;
}

export async function updateChatDescription(db: IDBDatabase, id: string, description: string): Promise<void> {
  const chat = await getMessagesByIdRaw(db, id);

  if (!chat) {
    throw new Error('Chat not found');
  }

  if (!description.trim()) {
    throw new Error('Description cannot be empty');
  }

  await setMessages(db, id, chat.messages, chat.urlId, description, chat.timestamp, chat.metadata);
}

export async function updateChatMetadata(
  db: IDBDatabase,
  id: string,
  metadata: IChatMetadata | undefined,
): Promise<void> {
  const chat = await getMessagesByIdRaw(db, id);

  if (!chat) {
    throw new Error('Chat not found');
  }

  await setMessages(db, id, chat.messages, chat.urlId, chat.description, chat.timestamp, metadata);
}

export async function getSnapshot(db: IDBDatabase, chatId: string): Promise<Snapshot | undefined> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('snapshots', 'readonly');
    const store = transaction.objectStore('snapshots');
    const request = store.get(chatId);

    request.onsuccess = () => resolve(request.result?.snapshot as Snapshot | undefined);
    request.onerror = () => reject(request.error);
  });
}

export async function setSnapshot(db: IDBDatabase, chatId: string, snapshot: Snapshot): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('snapshots', 'readwrite');
    const store = transaction.objectStore('snapshots');
    const request = store.put({ chatId, snapshot });

    transaction.oncomplete = () => resolve();
    request.onerror = () => reject(request.error);
    transaction.onerror = () => reject(transaction.error || request.error);
    transaction.onabort = () => reject(transaction.error || new Error('Chat snapshot save was aborted'));
  });
}

export async function deleteSnapshot(db: IDBDatabase, chatId: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('snapshots', 'readwrite');
    const store = transaction.objectStore('snapshots');
    const request = store.delete(chatId);

    request.onsuccess = () => resolve();

    request.onerror = (event) => {
      if ((event.target as IDBRequest).error?.name === 'NotFoundError') {
        resolve();
      } else {
        reject(request.error);
      }
    };
  });
}
