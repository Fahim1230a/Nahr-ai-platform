import { useCallback, useState } from 'react';
import { getMessageText } from '~/lib/persistence/messageMigration';
import { EnhancedStreamingMessageParser } from '~/lib/runtime/enhanced-message-parser';
import { workbenchStore } from '~/lib/stores/workbench';
import { createScopedLogger } from '~/utils/logger';

const logger = createScopedLogger('useMessageParser');

const messageParser = new EnhancedStreamingMessageParser({
  callbacks: {
    onArtifactOpen: (data) => {
      logger.trace('onArtifactOpen', data);

      workbenchStore.showWorkbench.set(true);
      workbenchStore.addArtifact(data);
    },
    onArtifactClose: (data) => {
      logger.trace('onArtifactClose');

      workbenchStore.updateArtifact(data, { closed: true });
    },
    onActionOpen: (data) => {
      logger.trace('onActionOpen', data.action);

      /*
       * File actions are streamed, so we add them immediately to show progress
       * Shell actions are complete when created by enhanced parser, so we wait for close
       */
      if (data.action.type === 'file') {
        workbenchStore.addAction(data);
      }
    },
    onActionClose: (data) => {
      logger.trace('onActionClose', data.action);

      /*
       * Add non-file actions (shell, build, start, etc.) when they close
       * Enhanced parser creates complete shell actions, so they're ready to execute
       */
      if (data.action.type !== 'file') {
        workbenchStore.addAction(data);
      }

      workbenchStore.runAction(data);
    },
    onActionStream: (data) => {
      logger.trace('onActionStream', data.action);
      workbenchStore.runAction(data, true);
    },
  },
});

export function useMessageParser() {
  const [parsedMessages, setParsedMessages] = useState<{ [key: number]: string }>({});

  /**
   * Drops the parser state and everything it has rendered so far.
   *
   * Required when another chat's history is loaded: the parser only emits the
   * artifact and action callbacks once per message id, so without a reset the
   * incoming chat would render on top of the outgoing one's output.
   */
  const resetParsedMessages = useCallback(() => {
    messageParser.reset();
    setParsedMessages({});
  }, []);

  const parseMessages = useCallback((messages: { id: string; role?: string }[], isLoading: boolean) => {
    for (const [index, message] of messages.entries()) {
      if (message.role === 'assistant' || message.role === 'user') {
        const newParsedContent = messageParser.parse(
          message.id,
          getMessageText(message),
          message.role === 'assistant' && !isLoading,
        );
        setParsedMessages((prevParsed) => ({
          ...prevParsed,
          [index]: (prevParsed[index] || '') + newParsedContent,
        }));
      }
    }
  }, []);

  return { parsedMessages, parseMessages, resetParsedMessages };
}
