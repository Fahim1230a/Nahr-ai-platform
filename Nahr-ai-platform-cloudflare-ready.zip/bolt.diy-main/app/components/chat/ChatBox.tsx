import { useStore } from '@nanostores/react';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import React from 'react';
import { ClientOnly } from 'remix-utils/client-only';
import { APIKeyManager } from './APIKeyManager';
import { AttachmentMenu } from './AttachmentMenu';
import styles from './BaseChat.module.scss';
import FilePreview from './FilePreview';
import { McpTools } from './MCPTools';
import { ScreenshotStateManager } from './ScreenshotStateManager';
import { SendButton } from './SendButton.client';
import { SupabaseConnection } from './SupabaseConnection';
import { ToolAccessMenu } from './ToolAccessMenu';
import { ModelSelector } from '~/components/chat/ModelSelector';
import { SpeechRecognitionButton } from '~/components/chat/SpeechRecognition';
import { ColorSchemeDialog } from '~/components/ui/ColorSchemeDialog';
import { IconButton } from '~/components/ui/IconButton';
import { ExpoQrModal } from '~/components/workbench/ExpoQrModal';
import type { ElementInfo } from '~/components/workbench/Inspector';
import { isGitHubConnected } from '~/lib/stores/githubConnection';
import { isGitLabConnected } from '~/lib/stores/gitlabConnection';
import { useMCPStore, type ConnectorId } from '~/lib/stores/mcp';
import { netlifyConnection } from '~/lib/stores/netlify';
import { LOCAL_PROVIDERS } from '~/lib/stores/settings';
import { supabaseConnection } from '~/lib/stores/supabase';
import { vercelConnection } from '~/lib/stores/vercel';
import type { DesignScheme } from '~/types/design-scheme';
import type { ProviderInfo } from '~/types/model';
import { classNames } from '~/utils/classNames';
import { PROVIDER_LIST } from '~/utils/constants';

interface ChatBoxProps {
  isModelSettingsCollapsed: boolean;
  setIsModelSettingsCollapsed: (collapsed: boolean) => void;
  provider: any;
  providerList: any[];
  modelList: any[];
  apiKeys: Record<string, string>;
  isModelLoading: string | undefined;
  onApiKeysChange: (providerName: string, apiKey: string) => void;
  uploadedFiles: File[];
  imageDataList: string[];
  textareaRef: React.RefObject<HTMLTextAreaElement | null> | undefined;
  input: string;
  handlePaste: (e: React.ClipboardEvent) => void;
  TEXTAREA_MIN_HEIGHT: number;
  TEXTAREA_MAX_HEIGHT: number;
  isStreaming: boolean;
  handleSendMessage: (event: React.UIEvent, messageInput?: string) => void;
  isListening: boolean;
  startListening: () => void;
  stopListening: () => void;
  chatStarted: boolean;
  exportChat?: () => void;
  qrModalOpen: boolean;
  setQrModalOpen: (open: boolean) => void;
  handleFileUpload: () => void;
  setProvider?: ((provider: ProviderInfo) => void) | undefined;
  model?: string | undefined;
  setModel?: ((model: string) => void) | undefined;
  setUploadedFiles?: ((files: File[]) => void) | undefined;
  setImageDataList?: ((dataList: string[]) => void) | undefined;
  handleInputChange?: ((event: React.ChangeEvent<HTMLTextAreaElement>) => void) | undefined;
  handleStop?: (() => void) | undefined;
  enhancingPrompt?: boolean | undefined;
  enhancePrompt?: (() => void) | undefined;
  chatMode?: 'discuss' | 'build';
  setChatMode?: (mode: 'discuss' | 'build') => void;
  agentMode?: boolean;
  setAgentMode?: (enabled: boolean) => void;
  designScheme?: DesignScheme;
  setDesignScheme?: (scheme: DesignScheme) => void;
  selectedElement?: ElementInfo | null;
  setSelectedElement?: ((element: ElementInfo | null) => void) | undefined;
}

export const ChatBox: React.FC<ChatBoxProps> = (props) => {
  const [isMcpToolsOpen, setIsMcpToolsOpen] = React.useState(false);
  const mcpToolsInitialized = useMCPStore((state) => state.isInitialized);
  const mcpSettings = useMCPStore((state) => state.settings);
  const setWebSearchEnabled = useMCPStore((state) => state.setWebSearchEnabled);
  const setConnectorEnabled = useMCPStore((state) => state.setConnectorEnabled);
  const serverTools = useMCPStore((state) => state.serverTools);
  const supabaseConnectionState = useStore(supabaseConnection);
  const supabaseConnected = !!supabaseConnectionState.isConnected;
  const githubConnected = useStore(isGitHubConnected);
  const gitlabConnected = useStore(isGitLabConnected);
  const vercelConnected = !!useStore(vercelConnection).user;
  const netlifyConnected = !!useStore(netlifyConnection).user;
  const browserUseCloudAvailable = serverTools['browser-use-cloud']?.status === 'available';

  const connectors = (
    [
      { id: 'github', name: 'GitHub', icon: <div className="i-ph:github-logo text-lg" />, available: githubConnected },
      {
        id: 'gitlab',
        name: 'GitLab',
        icon: <div className="i-ph:gitlab-logo text-lg" />,
        available: gitlabConnected,
      },
      {
        id: 'vercel',
        name: 'Vercel',
        icon: <div className="i-ph:triangle text-lg" />,
        available: vercelConnected,
      },
      {
        id: 'netlify',
        name: 'Netlify',
        icon: <div className="i-ph:cloud text-lg" />,
        available: netlifyConnected,
      },
      {
        id: 'supabase',
        name: 'Supabase',
        icon: <img className="w-4 h-4" height="16" width="16" src="https://cdn.simpleicons.org/supabase" alt="" />,
        available: supabaseConnected,
      },
      {
        id: 'browserUseCloud',
        name: 'Browser Use Cloud',
        icon: <div className="i-ph:browser text-lg" />,
        available: browserUseCloudAvailable,
      },
    ] as { id: ConnectorId; name: string; icon: React.ReactNode; available: boolean }[]
  )
    .filter((connector) => connector.available)
    .map(({ available: _available, ...connector }) => ({
      ...connector,
      enabled: mcpSettings.connectorEnabled[connector.id],
    }));

  React.useEffect(() => {
    const availability: Record<ConnectorId, boolean> = {
      github: githubConnected,
      gitlab: gitlabConnected,
      vercel: vercelConnected,
      netlify: netlifyConnected,
      supabase: supabaseConnected,
      browserUseCloud: browserUseCloudAvailable,
    };

    for (const [connector, available] of Object.entries(availability) as [ConnectorId, boolean][]) {
      if (!available && mcpSettings.connectorEnabled[connector]) {
        setConnectorEnabled(connector, false);
      }
    }
  }, [
    githubConnected,
    gitlabConnected,
    vercelConnected,
    netlifyConnected,
    browserUseCloudAvailable,
    mcpSettings.connectorEnabled.github,
    mcpSettings.connectorEnabled,
    setConnectorEnabled,
    supabaseConnected,
  ]);

  return (
    <div
      className={classNames(
        'relative bg-bolt-elements-background-depth-2 backdrop-blur p-3 rounded-lg border border-bolt-elements-borderColor relative w-full max-w-chat mx-auto z-prompt',

        /*
         * {
         *   'sticky bottom-2': chatStarted,
         * },
         */
      )}
    >
      <svg className={classNames(styles.PromptEffectContainer)}>
        <defs>
          <linearGradient
            id="line-gradient"
            x1="20%"
            y1="0%"
            x2="-14%"
            y2="10%"
            gradientUnits="userSpaceOnUse"
            gradientTransform="rotate(-45)"
          >
            <stop offset="0%" stopColor="#b44aff" stopOpacity="0%"></stop>
            <stop offset="40%" stopColor="#b44aff" stopOpacity="80%"></stop>
            <stop offset="50%" stopColor="#b44aff" stopOpacity="80%"></stop>
            <stop offset="100%" stopColor="#b44aff" stopOpacity="0%"></stop>
          </linearGradient>
          <linearGradient id="shine-gradient">
            <stop offset="0%" stopColor="white" stopOpacity="0%"></stop>
            <stop offset="40%" stopColor="#ffffff" stopOpacity="80%"></stop>
            <stop offset="50%" stopColor="#ffffff" stopOpacity="80%"></stop>
            <stop offset="100%" stopColor="white" stopOpacity="0%"></stop>
          </linearGradient>
        </defs>
        <rect className={classNames(styles.PromptEffectLine)} pathLength="100" strokeLinecap="round"></rect>
        <rect className={classNames(styles.PromptShine)} x="48" y="24" width="70" height="1"></rect>
      </svg>
      <div>
        <ClientOnly>
          {() => (
            <div className={props.isModelSettingsCollapsed ? 'hidden' : ''}>
              <ModelSelector
                key={props.provider?.name}
                model={props.model}
                setModel={props.setModel}
                modelList={props.modelList}
                provider={props.provider}
                setProvider={props.setProvider}
                providerList={props.providerList || (PROVIDER_LIST as ProviderInfo[])}
                apiKeys={props.apiKeys}
                modelLoading={props.isModelLoading}
              />
              {(props.providerList || []).length > 0 &&
                props.provider &&
                !LOCAL_PROVIDERS.includes(props.provider.name) && (
                  <APIKeyManager
                    provider={props.provider}
                    apiKey={props.apiKeys[props.provider.name] || ''}
                    setApiKey={(key) => {
                      props.onApiKeysChange(props.provider.name, key);
                    }}
                  />
                )}
            </div>
          )}
        </ClientOnly>
      </div>
      <FilePreview
        files={props.uploadedFiles}
        imageDataList={props.imageDataList}
        onRemove={(index) => {
          props.setUploadedFiles?.(props.uploadedFiles.filter((_, i) => i !== index));
          props.setImageDataList?.(props.imageDataList.filter((_, i) => i !== index));
        }}
      />
      <ClientOnly>
        {() => (
          <ScreenshotStateManager
            setUploadedFiles={props.setUploadedFiles}
            setImageDataList={props.setImageDataList}
            uploadedFiles={props.uploadedFiles}
            imageDataList={props.imageDataList}
          />
        )}
      </ClientOnly>
      {props.selectedElement && (
        <div className="flex mx-1.5 gap-2 items-center justify-between rounded-lg rounded-b-none border border-b-none border-bolt-elements-borderColor text-bolt-elements-textPrimary flex py-1 px-2.5 font-medium text-xs">
          <div className="flex gap-2 items-center lowercase">
            <code className="bg-accent-500 rounded-4px px-1.5 py-1 mr-0.5 text-white">
              {props?.selectedElement?.tagName}
            </code>
            selected for inspection
          </div>
          <button
            className="bg-transparent text-accent-500 pointer-auto"
            onClick={() => props.setSelectedElement?.(null)}
          >
            Clear
          </button>
        </div>
      )}
      <div
        className={classNames('relative shadow-xs border border-bolt-elements-borderColor backdrop-blur rounded-lg')}
      >
        <textarea
          ref={props.textareaRef}
          className={classNames(
            'w-full pl-4 pt-4 pr-16 outline-none resize-none text-bolt-elements-textPrimary placeholder-bolt-elements-textTertiary bg-transparent text-sm',
            'transition-all duration-200',
            'hover:border-bolt-elements-focus',
          )}
          onDragEnter={(e) => {
            e.preventDefault();
            e.currentTarget.style.border = '2px solid #1488fc';
          }}
          onDragOver={(e) => {
            e.preventDefault();
            e.currentTarget.style.border = '2px solid #1488fc';
          }}
          onDragLeave={(e) => {
            e.preventDefault();
            e.currentTarget.style.border = '1px solid var(--bolt-elements-borderColor)';
          }}
          onDrop={(e) => {
            e.preventDefault();
            e.currentTarget.style.border = '1px solid var(--bolt-elements-borderColor)';

            const files = Array.from(e.dataTransfer.files);
            files.forEach((file) => {
              if (file.type.startsWith('image/')) {
                const reader = new FileReader();

                reader.onload = (e) => {
                  const base64Image = e.target?.result as string;
                  props.setUploadedFiles?.([...props.uploadedFiles, file]);
                  props.setImageDataList?.([...props.imageDataList, base64Image]);
                };
                reader.readAsDataURL(file);
              }
            });
          }}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              if (event.shiftKey) {
                return;
              }

              event.preventDefault();

              if (props.isStreaming) {
                props.handleStop?.();
                return;
              }

              // ignore if using input method engine
              if (event.nativeEvent.isComposing) {
                return;
              }

              props.handleSendMessage?.(event);
            }
          }}
          value={props.input}
          onChange={(event) => {
            props.handleInputChange?.(event);
          }}
          onPaste={props.handlePaste}
          style={{
            minHeight: props.TEXTAREA_MIN_HEIGHT,
            maxHeight: props.TEXTAREA_MAX_HEIGHT,
          }}
          placeholder={props.chatMode === 'build' ? 'How can Bolt help you today?' : 'What would you like to discuss?'}
          translate="no"
        />
        <ClientOnly>
          {() => (
            <SendButton
              show={props.input.length > 0 || props.isStreaming || props.uploadedFiles.length > 0}
              isStreaming={props.isStreaming}
              disabled={!props.providerList || props.providerList.length === 0}
              onClick={(event) => {
                if (props.isStreaming) {
                  props.handleStop?.();
                  return;
                }

                if (props.input.length > 0 || props.uploadedFiles.length > 0) {
                  props.handleSendMessage?.(event);
                }
              }}
            />
          )}
        </ClientOnly>
        <div className="flex justify-between items-center text-sm p-4 pt-2">
          <div className="flex gap-1 items-center">
            <ClientOnly>
              {() => (
                <AttachmentMenu
                  onAttachFile={() => props.handleFileUpload()} // Opens image file picker (image/* only)
                  onOpenDesignDialog={() => {
                    /*
                     * Trigger the design dialog by programmatically clicking the hidden button
                     * This is a workaround since ColorSchemeDialog manages its own state
                     */
                    const designButton = document.querySelector('[title="Design Palette"]') as HTMLButtonElement;
                    designButton?.click();
                  }}
                  onEnhancePrompt={() => {
                    props.enhancePrompt?.();
                  }}
                  connectors={connectors}
                  onConnectorEnabledChange={setConnectorEnabled}
                  onOpenMcpTools={() => setIsMcpToolsOpen(true)}
                  mcpToolsInitialized={mcpToolsInitialized}
                  webSearchEnabled={mcpSettings.webSearchEnabled}
                  onWebSearchEnabledChange={setWebSearchEnabled}
                  enhancingPrompt={props.enhancingPrompt}
                  isEnhanceDisabled={props.input.length === 0 || props.enhancingPrompt}
                />
              )}
            </ClientOnly>
            <ClientOnly>{() => <ToolAccessMenu />}</ClientOnly>
            {/* Hidden components for programmatic access from menu */}
            <div className="hidden">
              <ColorSchemeDialog designScheme={props.designScheme} setDesignScheme={props.setDesignScheme} />
              <SupabaseConnection />
            </div>
            <McpTools open={isMcpToolsOpen} onOpenChange={setIsMcpToolsOpen} />
            <DropdownMenu.Root>
              <DropdownMenu.Trigger asChild>
                <button
                  type="button"
                  title={props.chatMode === 'discuss' ? 'Discuss Mode' : 'Agent Mode'}
                  className={classNames(
                    'transition-all flex items-center gap-1 rounded-md px-1.5 py-1 text-xs',
                    props.chatMode === 'discuss'
                      ? 'bg-bolt-elements-item-backgroundAccent text-bolt-elements-item-contentAccent'
                      : props.agentMode
                        ? 'bg-bolt-elements-item-backgroundAccent text-bolt-elements-item-contentAccent'
                        : 'bg-bolt-elements-item-backgroundDefault text-bolt-elements-item-contentDefault hover:bg-bolt-elements-item-backgroundActive',
                  )}
                >
                  {props.chatMode === 'discuss' ? (
                    <>
                      <div className="i-ph:chats text-lg" />
                      <span>Discuss</span>
                    </>
                  ) : (
                    <>
                      <div className="i-ph:robot text-lg" />
                      <span>Agent</span>
                    </>
                  )}
                  <div className="i-ph:caret-down text-sm" />
                </button>
              </DropdownMenu.Trigger>
              <DropdownMenu.Portal>
                <DropdownMenu.Content
                  className={classNames(
                    'min-w-[160px] rounded-lg p-1',
                    'bg-bolt-elements-background-depth-2',
                    'border border-bolt-elements-borderColor',
                    'shadow-lg',
                    'z-50',
                  )}
                  sideOffset={5}
                  align="start"
                >
                  <DropdownMenu.Item
                    className={classNames(
                      'flex items-center gap-2 px-3 py-2 rounded-md text-sm cursor-pointer',
                      'text-bolt-elements-textPrimary',
                      'hover:bg-bolt-elements-item-backgroundActive',
                      'focus:outline-none',
                      props.chatMode === 'build' && props.agentMode && 'bg-bolt-elements-item-backgroundAccent',
                    )}
                    onSelect={() => {
                      props.setChatMode?.('build');
                      props.setAgentMode?.(true);
                    }}
                  >
                    <div className="i-ph:robot text-lg" />
                    <div className="flex flex-col">
                      <span>Agent</span>
                      <span className="text-xs text-bolt-elements-textSecondary">Plans & uses tools</span>
                    </div>
                  </DropdownMenu.Item>
                  <DropdownMenu.Item
                    className={classNames(
                      'flex items-center gap-2 px-3 py-2 rounded-md text-sm cursor-pointer',
                      'text-bolt-elements-textPrimary',
                      'hover:bg-bolt-elements-item-backgroundActive',
                      'focus:outline-none',
                      props.chatMode === 'discuss' && 'bg-bolt-elements-item-backgroundAccent',
                    )}
                    onSelect={() => {
                      props.setChatMode?.('discuss');
                      props.setAgentMode?.(false);
                    }}
                  >
                    <div className="i-ph:chats text-lg" />
                    <div className="flex flex-col">
                      <span>Discuss</span>
                      <span className="text-xs text-bolt-elements-textSecondary">Chat without tools</span>
                    </div>
                  </DropdownMenu.Item>
                </DropdownMenu.Content>
              </DropdownMenu.Portal>
            </DropdownMenu.Root>
            <SpeechRecognitionButton
              isListening={props.isListening}
              onStart={props.startListening}
              onStop={props.stopListening}
              disabled={props.isStreaming}
            />
            <IconButton
              title="Model Settings"
              className={classNames('transition-all flex items-center gap-1', {
                'bg-bolt-elements-item-backgroundAccent text-bolt-elements-item-contentAccent':
                  props.isModelSettingsCollapsed,
                'bg-bolt-elements-item-backgroundDefault text-bolt-elements-item-contentDefault':
                  !props.isModelSettingsCollapsed,
              })}
              onClick={() => props.setIsModelSettingsCollapsed(!props.isModelSettingsCollapsed)}
              disabled={!props.providerList || props.providerList.length === 0}
            >
              <div className={`i-ph:caret-${props.isModelSettingsCollapsed ? 'right' : 'down'} text-lg`} />
              {props.isModelSettingsCollapsed ? (
                <span className="text-xs" title={props.model}>
                  {props.model && props.model.length > 25 ? `${props.model.slice(0, 22)}...` : props.model}
                </span>
              ) : (
                <span />
              )}
            </IconButton>
          </div>
          <ExpoQrModal open={props.qrModalOpen} onClose={() => props.setQrModalOpen(false)} />
        </div>
      </div>
    </div>
  );
};
