/**
 * DOM-only test setup, loaded by the jsdom Vitest project.
 *
 * Loaded after tests/setup-base.ts, which supplies the matchers. Everything here
 * touches `window`/`document`/`localStorage` and therefore only runs where a DOM
 * exists.
 */

import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, vi } from 'vitest';

// RTL cleanup + storage reset. Storage is cleared here rather than in the base
// file because `localStorage` only exists in this environment.
afterEach(() => {
  cleanup();
  localStorage.clear();
});

// Mock window.matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
});

// Mock Worker API with proper Shiki highlighting simulation
class WorkerMock {
  url: string;
  onmessage: ((event: MessageEvent) => void) | null = null;

  constructor(url: string | URL) {
    this.url = url.toString();
  }

  postMessage(data: any) {
    // Mock worker behavior - simulate Shiki highlighting with language-specific output
    setTimeout(() => {
      if (this.onmessage) {
        // Simulate actual syntax highlighting output with proper HTML
        // Include language in the output to make each language unique
        const languageClass = `language-${data.language || 'plaintext'}`;
        const highlighted = `<pre class="shiki ${languageClass}" style="background-color:#1e1e1e"><code><span style="color:#9CDCFE">${this.escapeHtml(data.code)}</span></code></pre>`;

        const event = new MessageEvent('message', {
          data: {
            id: data.id,
            html: highlighted,
          },
        });
        this.onmessage(event);
      }
    }, 0);
  }

  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  addEventListener(type: string, listener: EventListenerOrEventListenerObject) {
    if (type === 'message' && typeof listener === 'function') {
      this.onmessage = listener as (event: MessageEvent) => void;
    }
  }

  removeEventListener() {}

  terminate() {}
}

global.Worker = WorkerMock as any;

// Mock window.requestAnimationFrame
global.requestAnimationFrame = vi.fn((callback) => {
  setTimeout(callback, 0);
  return 0;
});

global.cancelAnimationFrame = vi.fn();

// Mock performance.mark and performance.measure
if (typeof performance !== 'undefined') {
  performance.mark = vi.fn();
  performance.measure = vi.fn();
  performance.clearMarks = vi.fn();
  performance.clearMeasures = vi.fn();
  performance.getEntriesByName = vi.fn(() => [{ duration: 10 } as any]);
  performance.getEntriesByType = vi.fn(() => [
    {
      fetchStart: 0,
      loadEventEnd: 100,
      domContentLoadedEventEnd: 50,
      domInteractive: 30,
      type: 'navigate',
    } as any,
  ]);
}

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value.toString();
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
    get length() {
      return Object.keys(store).length;
    },
    key: (index: number) => {
      const keys = Object.keys(store);
      return keys[index] || null;
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
  writable: true,
});

// Mock PerformanceObserver
global.PerformanceObserver = class PerformanceObserver {
  constructor(public callback: PerformanceObserverCallback) {}
  observe() {}
  disconnect() {}
  takeRecords() {
    return [];
  }
} as any;

// Mock web-vitals library
vi.mock('web-vitals', () => ({
  onCLS: vi.fn((callback) => {
    // Simulate CLS metric
    setTimeout(() => callback({ value: 0.05, id: 'cls-1', name: 'CLS' }), 0);
  }),
  onFID: vi.fn((callback) => {
    // Simulate FID metric
    setTimeout(() => callback({ value: 50, id: 'fid-1', name: 'FID' }), 0);
  }),
  onLCP: vi.fn((callback) => {
    // Simulate LCP metric
    setTimeout(() => callback({ value: 1200, id: 'lcp-1', name: 'LCP' }), 0);
  }),
  onFCP: vi.fn((callback) => {
    // Simulate FCP metric
    setTimeout(() => callback({ value: 800, id: 'fcp-1', name: 'FCP' }), 0);
  }),
  onTTFB: vi.fn((callback) => {
    // Simulate TTFB metric
    setTimeout(() => callback({ value: 200, id: 'ttfb-1', name: 'TTFB' }), 0);
  }),
  onINP: vi.fn((callback) => {
    // Simulate INP metric
    setTimeout(() => callback({ value: 150, id: 'inp-1', name: 'INP' }), 0);
  }),
}));